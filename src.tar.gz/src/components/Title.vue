<template>
	<h3>{{title}}</h3>
</template>

<script>
export default {
	name: 'TitleView',
	props: {
		title: String, 
	}
}
</script>

<style lang="scss" scoped>

</style>